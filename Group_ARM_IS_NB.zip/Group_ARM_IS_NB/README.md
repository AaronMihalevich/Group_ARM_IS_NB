Week 5 Javascript group project
Aaron Mihalevich
Nathan Burky
Isaic Stomboly

CIS-131-101 09/9/19

Create a site for a local business in Springfield MO.
"# Group_ARM_IS_NB" 
